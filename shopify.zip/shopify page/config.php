<?php return array (
  'store' => 
  array (
    'theme_color' => '#000000',
    'name' => 'STORE NAME',
    'currency' => 'EUR',
    'logo' => '/assets/images/61jQTglTS3L._AC_SL1500.webp',
  ),
  'product' => 
  array (
    'image' => '/img/logo.jpg',
    'name' => 'Product Name',
    'price' => 0.0,
    'size' => '',
    'shipping' => 
    array (
      'method' => 'Standard Shipping',
      'price' => 'FREE',
    ),
  ),
  'generated_links' => 
  array (
    'store_67c6b60c37d67' => 
    array (
      'id' => 'store_67c6b60c37d67',
      'created_at' => '2025-03-04 08:13:00',
      'store' => 
      array (
        'name' => 'Hot Sew',
        'currency' => 'USD',
        'theme_color' => '#ff8080',
        'logo' => '/assets/images/links/store_67c6b60c37d67/logo.jpg',
      ),
      'product' => 
      array (
        'name' => 'Side Cutter Presser Foot',
        'price' => 3.9,
        'size' => '',
        'image' => '/assets/images/links/store_67c6b60c37d67/61mUFW3CXKL._AC_SL1500.webp',
        'shipping' => 
        array (
          'method' => 'Standard Shipping',
          'price' => 'FREE',
        ),
      ),
    ),
    'store_67c6bc54de0bf' => 
    array (
      'id' => 'store_67c6bc54de0bf',
      'created_at' => '2025-03-04 08:39:48',
      'store' => 
      array (
        'name' => 'JOUDIA STORE',
        'currency' => 'EUR',
        'theme_color' => '#205ed9',
        'logo' => '/assets/images/61jQTglTS3L._AC_SL1500.webp',
      ),
      'product' => 
      array (
        'name' => 'Pringles',
        'price' => 80.0,
        'size' => 'S',
        'image' => '/assets/images/links/store_67c6bc54de0bf/IMG_4672.jpg',
        'shipping' => 
        array (
          'method' => 'Standard Shipping',
          'price' => 'FREE',
        ),
      ),
    ),
    'store_67c6c1b4a03aa' => 
    array (
      'id' => 'store_67c6c1b4a03aa',
      'created_at' => '2025-03-04 09:02:44',
      'store' => 
      array (
        'name' => 'STORE NAME',
        'currency' => 'EUR',
        'theme_color' => '#000000',
        'logo' => '/assets/images/61jQTglTS3L._AC_SL1500.webp',
      ),
      'product' => 
      array (
        'name' => 'MOURAD',
        'price' => 10.0,
        'size' => '',
        'image' => '/img/logo.jpg',
        'shipping' => 
        array (
          'method' => 'Standard Shipping',
          'price' => 'FREE',
        ),
      ),
      'tracking' => 
      array (
        'facebook_pixel' => '24000473539555555',
        'tiktok_pixel' => '',
      ),
    ),
  ),
);